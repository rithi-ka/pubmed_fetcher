import click
import csv
from typing import Optional
from pubmed_fetcher.core import fetch_pubmed_papers

@click.command()
@click.argument("query")
@click.option("-f", "--file", type=click.Path(), help="Output CSV filename.")
@click.option("-d", "--debug", is_flag=True, help="Enable debug mode.")
def main(query: str, file: Optional[str], debug: bool) -> None:
    """Fetch PubMed papers by QUERY and output results to console or CSV file."""
    click.echo(f"Fetching papers for query: '{query}'...")
    
    try:
        results = fetch_pubmed_papers(query, debug=debug)
    except Exception as e:
        click.echo(f"Error: {e}")
        return

    if not results:
        click.echo("No matching papers found.")
        return

    if file:
        with open(file, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=results[0].keys())
            writer.writeheader()
            writer.writerows(results)
        click.echo(f"Results written to {file}")
    else:
        for paper in results:
            click.echo("=" * 60)
            for key, value in paper.items():
                click.echo(f"{key}: {value}")
