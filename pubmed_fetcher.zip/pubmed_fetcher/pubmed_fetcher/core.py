from typing import List, Dict, Optional
from Bio import Entrez
import re
import logging

Entrez.email = "rithikakuppala48@gmail.com"

def is_non_academic(affiliation: str) -> bool:
    """Determine if an affiliation is likely non-academic."""
    academic_keywords = [
        "university", "college", "institute", "school",
        "hospital", "clinic", "center", "centre", "faculty", "department", "lab"
    ]
    return not any(word in affiliation.lower() for word in academic_keywords)

def extract_email(affiliations: List[str]) -> Optional[str]:
    """Extract first email found in affiliations list."""
    for aff in affiliations:
        match = re.search(r'[\w\.-]+@[\w\.-]+', aff)
        if match:
            return match.group()
    return None

def fetch_pubmed_papers(query: str, debug: bool = False) -> List[Dict[str, Optional[str]]]:
    """Fetch PubMed papers and extract industry-affiliated author information."""
    results = []

    if debug:
        logging.basicConfig(level=logging.DEBUG)

    search_handle = Entrez.esearch(db="pubmed", term=query, retmax=20)
    search_results = Entrez.read(search_handle)
    search_handle.close()

    id_list = search_results["IdList"]
    if debug:
        logging.debug(f"Found {len(id_list)} articles.")

    if not id_list:
        return []

    fetch_handle = Entrez.efetch(db="pubmed", id=",".join(id_list), rettype="medline", retmode="text")
    records = fetch_handle.read()
    fetch_handle.close()

    from io import StringIO
    from Bio import Medline

    medline_records = Medline.parse(StringIO(records))

    for record in medline_records:
        pmid = record.get("PMID", "")
        title = record.get("TI", "")
        date = record.get("DP", "")
        authors = record.get("FAU", [])
        affiliations_raw = record.get("AD", [])

        affiliations = []
        if isinstance(affiliations_raw, str):
            affiliations = [affiliations_raw]
        elif isinstance(affiliations_raw, list):
            affiliations = affiliations_raw

        company_affiliations = [aff for aff in affiliations if is_non_academic(aff)]

        if company_affiliations:
            results.append({
                "PubmedID": pmid,
                "Title": title,
                "Publication Date": date,
                "Non-academic Author(s)": ", ".join(authors),
                "Company Affiliation(s)": "; ".join(company_affiliations),
                "Corresponding Author Email": extract_email(affiliations),
            })

    return results



