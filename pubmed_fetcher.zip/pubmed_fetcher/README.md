# pubmed-fetcher

**pubmed-fetcher** is a Python command-line tool to search PubMed for biomedical research articles and identify papers with at least one author affiliated with a **pharmaceutical or biotech company**. It uses the [Entrez API](https://www.ncbi.nlm.nih.gov/books/NBK25501/) via Biopython and outputs structured results to a CSV file.

---

## 🚀 Features

- 🔍 Search PubMed with custom queries.
- 🏢 Detect non-academic authors using heuristics.
- 📬 Extract corresponding author emails.
- 📁 Export data to CSV or view on console.
- ⚙️ CLI interface built with `click`.
- 📦 Easily installable with `poetry`.

---

## 📦 Installation

Ensure Python **3.12+** is installed.

### 1. Clone the project

```bash
git clone https://github.com/your-username/pubmed-fetcher.git
cd pubmed-fetcher

2. Install with Poetry
If you haven’t installed Poetry, do that first.


poetry install

If you see an error about missing README, ensure you have this file in the root folder.

🧪 Usage
Run the CLI using Poetry:



poetry run get-papers-list "lung cancer" -f results.csv -d

CLI Options:
Option	Description
-f, --file	Output CSV filename (e.g., results.csv)
-d, --debug	Enable debug logging
-h, --help	Show help message